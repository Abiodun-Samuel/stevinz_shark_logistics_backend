<?php

namespace Database\Factories\Api;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;
use Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Api\Inventory>
 */
class InventoryFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $nigerianCities = [
            'Benin',
            'Auchi',
            'Ekpoma',
            'Uromi',
            'Warri',
            'Abraka',
            'Sapele',
            'Ugheli',
            'Oghara',
            'Agbor',
            'Asaba',
            'Onitsha',
            'Ihiala',
            'Awka',
            'Enugu',
            'Nnsuka',
            'Abakaliki',
            'Nnewi',
            'Ekwulobia',
            'Owerri',
            'Port Harcourt',
            'Bayelsa',
            'Abuja',
            'Lokoja',
            'Sokoto',
            'ABA',
            'Umuahia',
            'Uyo',
            'Calabar',
            'Ibadan',
            'Iwo road',
            'Challenge',
            'Osogbo',
            'Abeokuta',
            'Ekiti',
            'Ado-Ekiti',
            'Ilorin',
            'Kwara',
        ];

        $nigerian = [
            'LAG',
            'ABJ',
            'IBD',
            'KAN',
            'PHC',
            'ENU',
            'BEN',
            'JOS',
            'ABK',
            'ONI',
            'UYO',
            'CAL',
            'KAD',
            'MAI',
            'WAR',
            'OWE',
            'ILO',
            'OSO',
            'MAK',
            'MIN',
            'BAU',
            'GOM',
            'EKI',
            'ASA'
        ];
        $shipmentNumber = fake()->randomElement($nigerian) . '-' . fake()->randomNumber(3, true) . '-' . fake()->randomNumber(4, true);
        return [
            'user_id' => User::inRandomOrder()->first()->id,
            'shipment_number' => $shipmentNumber,
            'item' => fake()->words(3, true),
            'location' => fake()->randomElement($nigerianCities),
            'sender' => fake()->phoneNumber(),
            'receiver' => fake()->phoneNumber(),
            'volume' => fake()->numberBetween(10, 50) . ' X ' . fake()->numberBetween(10, 50) . ' X ' . fake()->numberBetween(10, 50),
            'branch' => fake()->randomElement($nigerianCities),
            'payment_mode' => fake()->randomElement(['cash', 'transfer', 'debit']),
            'created_at' => Carbon::create(2025, 1, 1)->addDays(fake()->numberBetween(0, 37)),
            'updated_at' => Carbon::create(2025, 1, 1)->addDays(fake()->numberBetween(0, 37)),
        ];
    }
}
