<?php

namespace Database\Seeders\Api;

use App\Models\Api\Location;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $nigerianCities = [
            'Benin',
            'Auchi',
            'Ekpoma',
            'Uromi',
            'Warri',
            'Abraka',
            'Sapele',
            'Ugheli',
            'Oghara',
            'Agbor',
            'Asaba',
            'Onitsha',
            'Ihiala',
            'Awka',
            'Enugu',
            'Nnsuka',
            'Abakaliki',
            'Nnewi',
            'Ekwulobia',
            'Owerri',
            'Port Harcourt',
            'Bayelsa',
            'Abuja',
            'Lokoja',
            'Sokoto',
            'ABA',
            'Umuahia',
            'Uyo',
            'Calabar',
            'Ibadan',
            'Iwo road',
            'Challenge',
            'Osogbo',
            'Abeokuta',
            'Ekiti',
            'Ado-Ekiti',
            'Ilorin',
            'Kwara',
        ];

        foreach ($nigerianCities as $key => $value) {
            Location::create([
                'city' => $value,
                'city_code' => strtoupper(substr($value, 0, 3))
            ]);
        }
    }
}
