<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\InventoryRequest;
use App\Models\Api\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Inventory::query();

        $filters = [
            'payment_mode' => 'payment_mode',
            'user_id' => 'user_id',
            'location' => 'location',
        ];

        foreach ($filters as $requestKey => $dbColumn) {
            if ($request->filled($requestKey)) {
                $query->where($dbColumn, $request->query($requestKey));
            }
        }

        if ($request->filled(['start_date', 'end_date'])) {
            $start_date = Carbon::createFromFormat('Y/m/d', $request->query('start_date'))->startOfDay();
            $end_date = Carbon::createFromFormat('Y/m/d', $request->query('end_date'))->endOfDay();
            $query->whereBetween('created_at', [$start_date, $end_date]);
        }

        if ($request->filled(['search_query'])) {
            $search_query = $request->input('search_query');
            $query->where('item', 'like', "%$search_query%")
                ->orWhere('location', 'like', "%$search_query%")
                ->orWhere('branch', 'like', "%$search_query%")
                ->orWhere('shipment_number', 'like', "%$search_query%")
                ->orWhere('payment_mode', 'like', "%$search_query%")
                ->orWhere('receiver', 'like', "%$search_query%")
                ->orWhere('sender', 'like', "%$search_query%");
        }

        if ($request->filled(['order_column', 'order_state'])) {
            $query->orderBy($request->query('order_column'), $request->query('order_state'));
        }

        $inventories = $query->with(['user'])->paginate(50);
        return $this->successResponse($inventories, '', 200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(InventoryRequest $request)
    {
        $validated = $request->validated();
        $inventory = Inventory::create($validated);
        return $this->successResponse($inventory, 'New inventory has been created successfully', 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Inventory $inventory)
    {
        return $this->successResponse($inventory, 'success', 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(InventoryRequest $request, Inventory $inventory)
    {
        $validated = $request->validated();
        $inventory->update([
            'user_id' => $validated['user_id'],
            'shipment_number' => $validated['shipment_number'],
            'item' => $validated['item'],
            'location' => $validated['location'],
            'sender' => $validated['sender'],
            'receiver' => $validated['receiver'],
            'volume' => $validated['volume'],
            'branch' => $validated['branch'],
            'payment_mode' => $validated['payment_mode'],
        ]);
        return $this->successResponse([], 'Inventory has been updated successfully', 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Inventory $inventory)
    {
        $inventory?->delete();
        return $this->successResponse([], 'Inventory has been deleted successfully', 200);
    }
    public function trackInventory(Request $request)
    {
        $validated = $request->validate([
            'shipment_number' => ['required', 'string'],
        ]);
        $inventory = Inventory::with('timelines')->where('shipment_number', $validated['shipment_number'])->first();
        return $this->successResponse($inventory, 'Successful', 200);
    }
}
